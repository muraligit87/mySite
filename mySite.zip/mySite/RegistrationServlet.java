//LoginServlet

import javax.servlet.*;
import java.io.*;
import java.sql.*;


public class RegistrationServlet extends GenericServlet {

	private Connection con;
	private PreparedStatement ps=null;

	public void init() throws ServletException {
		System.out.println("In init");
		try {
			ServletContext ctxt=getServletContext();
			//Getting the Driver class name from context parameter
			String driverClassName=ctxt.getInitParameter("driverClassName");
			Class.forName(driverClassName);
			//Getting the JDBC URL from context parameter
			String url=ctxt.getInitParameter("url");
			
			//Getting the DB Username, password & sqlstatement from servlet init parameter
			String dbuser=getInitParameter("dbuser");
			String dbpass=getInitParameter("dbpass");
			String sqlst=getInitParameter("sqlstatement");
			
			con=DriverManager.getConnection(url, dbuser, dbpass);
			ps=con.prepareStatement(sqlst);
		}//try
		catch(Exception e){
			e.printStackTrace();
			throw new ServletException("Initialization failed, Unable to get DB connection");
		}//catch
	}//init

	public void service (ServletRequest req, ServletResponse res) throws ServletException, IOException {

		System.out.println("In service");

		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		try {

			String uname=req.getParameter("uname");
			String pass= req.getParameter("pass");
			String repass= req.getParameter("repass");

			if (uname==null||uname.equals("")
				||pass==null||pass.equals("")
				||!pass.equals(repass)) {

				out.println("<html><body><center>");
				out.println("<li><i>Given details are not valid to register</i></li><br/>");
				out.println("<li><i>Please try again later</i>");
				out.println("</center></body></html>");
				return;
			}//if

			String addr=req.getParameter("addr");
			String phno=req.getParameter("phno");
			String email=req.getParameter("email");
			
			ps.setString(1,uname);
			ps.setString(2,pass);
			ps.setString(3,addr);
			ps.setString(4,phno);
			ps.setString(5,email);

			int count=ps.executeUpdate();

			if (count==1||count==Statement.SUCCESS_NO_INFO){
				out.println("<html><body>");
				out.println("<BODY bgcolor=plasma text=maroon>");
				out.println("<center><h1>GMK Industries Ltd.</h1></center>");
				out.println("<table border=\"1\" width=\"100%\" height=\"100%\">");
				out.println("<tr>");
				out.println("<td width=\"15%\" valign=\"top\" align=\"center\">");
				out.println("<br/><a href=\"Login.html\">Login</a><br/>");
				out.println("<br/><a href=\"Register.html\">Register</a><br/>");
				out.println("</td>");
				out.println("<td valign=\"top\" align=\"center\"><br/>");
				out.println("<h3>Welcome to "+uname+"</h3><br/>");
				out.println("<h2>Enjoy browsing with GMK Servieces</h2>");
				out.println("</td></tr></table>");
				out.println("</body></html>");
			}
			else{
				out.println("<html><body><center>");
				out.println("<BODY bgcolor=plasma text=maroon>");
				out.println("Given details are incorrect<br/>");
				out.println("<li><i>Please try again later</i>");
				out.println("</center></body></html>");				
			}
		}//try
		catch(Exception e){
			out.println("<html><body><center>");
			out.println("<h2>Unable to the process the request try after some time</h2>");
			out.println("</center></body></html>");
		}//catch
	}//service

	public void destroy () {
		System.out.println("In destroy");
		try {con.close();}
		catch(Exception e){}
	}//destroy
}//class
